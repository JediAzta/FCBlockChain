#### flask-demo（deploy a flask-based project to function compute）

Through this template demo, the user can create a serverless flask web project, and invoke the function via URL.
users can call function via url named "$(account-id).$(region).fc.aliyuncs.com/2016-08-15/proxy/serviceName/functionName/'"
For example: account-id is 12345, the region of cn-Shanghai, serviceName fcService, functionName to test, then the url is 12345. cn-shanghai.fc.aliyuncs.com/2016-08-15/proxy/fcservice/test/ access functions

#### Input parameters

No (HTTP trigger)

#### Output parameters

Web HTML page